
  {{-- header --}}
  @include('layouts.header')

  <!-- ======= Hero Section ======= -->
  @yield('content')
  <!-- End #main -->

  <!-- ======= Footer ======= -->

  @include('layouts.footer')
  <!-- End Footer -->